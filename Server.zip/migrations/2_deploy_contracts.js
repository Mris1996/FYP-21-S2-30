const ConvertLib = artifacts.require("ConvertLib");
const STIContract = artifacts.require("STIContract");
module.exports = function(deployer) {
  deployer.deploy(ConvertLib);
  deployer.link(ConvertLib, STIContract);
  deployer.deploy(STIContract,0);
  
};
